#ifndef _SWITCH_H_
#define _SWITCH_H_

#ifndef True
#define True    1
#endif

#ifndef False
#define False   0
#endif

void InitializeSwitch(void);
char SW1(void);
char SW2(void);

#endif