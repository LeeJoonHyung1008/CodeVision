#include <mega128.h>
#include <delay.h>
#include "Sensor.h"
#include "StepMotor.h"
#include "LED.h"
#include "switch.h"
#include "Algorithm.h"
#include <stdio.h>

unsigned int Front[5]={0}, Right[5]={0}, Left[5] = {0};

// Declare your global variables here
extern unsigned int VelocityLeftmotorTCNT1, VelocityRightmotorTCNT3;
void InitializeUART(void){ // UART ����� ���� �� register�� �ʱ�ȭ �Ѵ�.
 // USART1 initialization
 // Communication Parameters: 8 Data, 1 Stop, No Parity
 // USART1 Receiver: On
 // USART1 Transmitter: On
 // USART1 Mode: Asynchronous
 // USART1 Baud Rate: 9600
 UCSR1A=0x00; // UART 1�� ä�ο� ���� register�� �ʱ�ȭ�Ѵ�.
 UCSR1B=0x18;
 UCSR1C=0x06;
 UBRR1H=0x00;
 UBRR1L=0x67;
} 

//eeprom extern int StandardSensor[3], CenterStandardSensor[3];

void main(void)
{
int i;
int mode;
i=0;
mode=0;
  
     InitializeSensor();
     InitializeUART(); 
       InitializeLED();    
     InitializeSwitch(); 
     InitializeStepmotor();              
     LED_OFF(LED1 | LED2 | LED3 | LED4);
     #asm("sei")
while(1)
{
     if(SW1() == TRUE)
     {
    mode++;
    mode%=4;
    LED_OFF(LED1 | LED2 | LED3 | LED4);
    switch(mode)
    {
    case 0: LED_ON(LED1); break;
    case 1: LED_ON(LED2); break;
    case 2: LED_ON(LED3); break;
    case 3: LED_ON(LED4); break;
    }
     }
     if(SW2() == TRUE)
     {
    switch(mode)
    {
    case 0:  
     //    Direction(FORWARD);       Direction(FORWARD);      Direction(FORWARD);     Direction(FORWARD);
         Direction(RIGHT);
         Direction(RIGHT);
         Direction(RIGHT);
         Direction(RIGHT);
    break;
    case 1:
         delay_ms(20); // ����� �� ����� �� ������ �߰��ߴ�.
         printf("CENTER : %d LEFT : %d RIGHT : %d\r\n",readSensor(FRONT_SENSOR),readSensor(LEFT_SENSOR),readSensor(RIGHT_SENSOR));
//         Direction(FORWARD);       
//         Direction(FORWARD);      
 //        Direction(FORWARD);     
 //        Direction(FORWARD);
         break;
    case 2:
               LED_OFF(LED1 | LED2 | LED3 | LED4);
         while(!SW2());
         StandardSensor[1] = readSensor(FRONT_SENSOR);    // ���� �� ����
         LED_ON(LED1);
         while(!SW2());
         StandardSensor[0] = readSensor(LEFT_SENSOR);    // ���� �� ����
         LED_ON(LED2);
         while(!SW2());
         StandardSensor[2] = readSensor(RIGHT_SENSOR);    // ������ �� ����
         LED_ON(LED3);
         while(!SW2());
         CenterStandardSensor[0] = readSensor(LEFT_SENSOR);    // �ڼ����� ���� �� ����
         CenterStandardSensor[2]= readSensor(RIGHT_SENSOR);    // �ڼ����� ������ �� ���� 
         CenterStandardSensor[1]= readSensor(FRONT_SENSOR);    // �ڼ����� ����
         LED_ON(LED4);
               LED_OFF(LED1 | LED2 | LED3 | LED4);
         LED_ON(LED3);       
         printf("left standard : %d    center stand : %d    right stand : %d    center standatd : %d  %d  %d",StandardSensor[0],StandardSensor[1],StandardSensor[2],CenterStandardSensor[0],CenterStandardSensor[1],CenterStandardSensor[2]);
         break;
    case 3:
         {
        printf("left standard : %d    center stand : %d    right stand : %d    center standatd : %d  %d  %d",StandardSensor[0],StandardSensor[1],StandardSensor[2],CenterStandardSensor[0],CenterStandardSensor[1],CenterStandardSensor[2]); 
               while (1)
               {
                    if(readSensor(LEFT_SENSOR) < StandardSensor[1])
                    {
                         LED_ON(LED3);
                         LED_OFF(LED4);
                         Direction(HALF);
                         Direction(SmoothL);
                         delay_ms(500);
                         LED_OFF(LED3);
                         LED_OFF(LED4);
                         Direction(HALF);
                    }
                    else if(readSensor(FRONT_SENSOR) > StandardSensor[0])
                    {
                         if(readSensor(RIGHT_SENSOR) < StandardSensor[2])
                         {
                              LED_OFF(LED3);
                              LED_ON(LED4);
               Direction(HALF);
                              Direction(SmoothR);
                              delay_ms(500);
                              LED_OFF(LED3);
                              LED_OFF(LED4);
                              Direction(HALF);
                         }
                         else
                         {
                              LED_ON(LED3);
                              LED_ON(LED4);
             Direction(HALF);
                              Direction(LEFT);
                              Direction(LEFT);
             Direction(HALF);
                         }
                    }
                    else
                    {
                         LED_OFF(LED3);
                         LED_OFF(LED4);
                         Direction(FORWARD);
                    }
               }         

        }                   
        break;
   }
     }  
     
}     ;
}